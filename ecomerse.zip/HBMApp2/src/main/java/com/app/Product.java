package com.app;

public class Product {
	private int pid;
	private String pName;
	private float price;
	private String brand;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Product(int pid, String pName, float price, String brand) {
		super();
		this.pid = pid;
		this.pName = pName;
		this.price = price;
		this.brand = brand;
	}
	

}
