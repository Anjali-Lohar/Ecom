package com.app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Configuration con=new Configuration().configure("product.cfg.xml");
SessionFactory factory=con.buildSessionFactory();
Session session=factory.openSession();
Transaction tx=session.beginTransaction();
Product product=new Product(1001, "Mobile", 23000.0f, "MI");
session.save(product);
tx.commit();
session.close();
System.out.println("Record inserted..."+product);
	}

}
